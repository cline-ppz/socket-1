package socket;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;
import java.util.regex.Matcher;   
import java.util.regex.Pattern;
 
public class Client { 

	public static void main(String[] args) throws Exception{
		int port = 33031;
		String host = "127.0.0.1";
		Socket socket = new Socket(host,port);
		
		InputStream is = socket.getInputStream();
		OutputStream os = socket.getOutputStream();
		
		BufferedReader br = new BufferedReader(new InputStreamReader(is));
		PrintWriter pw = new PrintWriter(new OutputStreamWriter(os));
		
		Scanner scan = new Scanner(System.in);
		pw.println("connect");
		pw.flush();
		
		String ans= br.readLine();
		System.out.println(ans); 
		
		while(!ans.equals("欢迎进入聊天室")) {
			
			ans= br.readLine();
			System.out.println(ans); 
			
			String user = scan.nextLine();
			pw.println(user); 
			pw.flush();
			
			ans= br.readLine();
			System.out.println(ans);
			
			String pass = scan.nextLine();
			pw.println(pass);
			pw.flush();
			
			ans= br.readLine(); 
			System.out.println(ans);
		}  
		  
		while(true){
			System.out.print("发送信息：");
			String str = scan.nextLine(); 
			pw.println(str);	
			pw.flush();
			
			     
			String aws = br.readLine();
			System.out.println("回复:"+aws); 
			
			
			if(str.equals("bye"))
				break;
		}
		socket.close();
		System.out.println("客户端程序结束");

	}
	
	 

}
